import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-call-for-papers',
  templateUrl: './call-for-papers.component.html',
  styleUrls: ['./call-for-papers.component.css']
})
export class CallForPapersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
