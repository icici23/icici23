import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-keynote',
  templateUrl: './keynote.component.html',
  styleUrls: ['./keynote.component.css']
})
export class KeynoteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
